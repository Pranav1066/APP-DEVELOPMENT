import React from 'react';
import { Link } from 'react-router-dom';
import './NvidiaHomePage.css'; // Ensure the CSS file is imported

const NvidiaHomePage = () => {
  return (
    <div className="page-wrapper">
      <main>
        {/* Navigation */}
        <nav className="navbar">
          <div className="container">
            <div className="logo">Healthcare</div>
            <div className="nav-links">
              <Link to="#" className="nav-link">Products</Link>
              <Link to="#" className="nav-link">Solutions</Link>
              <Link to="#" className="nav-link">Support</Link>
              <Link to="#" className="nav-link">Shop</Link>
              <Link to="/" className="nav-link">Login</Link>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <header className="hero-section">
          <div className="container">
            <h1 className="hero-title">Welcome to Healthcare</h1>
            <p className="hero-subtitle">Empowering Your Wellness Journey</p>
            <button className="explore-button">Discover Our Services</button>
          </div>
        </header>

        {/* Featured Products */}
        <section className="featured-services">
          <div className="container">
            <h2 className="section-title">Featured Services</h2>
            <div className="services-grid">
              <div className="service-card">
                <h3 className="service-title">Personal Training</h3>
                <p>Get customized workout plans with our expert trainers.</p>
              </div>
              <div className="service-card">
                <h3 className="service-title">Nutrition Counseling</h3>
                <p>Personalized nutrition plans to achieve your health goals.</p>
              </div>
              <div className="service-card">
                <h3 className="service-title">Yoga Classes</h3>
                <p>Join our yoga sessions to enhance your mind and body balance.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Latest News */}
        <section className="latest-news">
          <div className="container">
            <h2 className="section-title">Latest News</h2>
            <div className="news-grid">
              <div className="news-card">
                <h3 className="news-title">New Nutrition Guide Released</h3>
                <p>Check out our latest guide to healthy eating and meal planning.</p>
              </div>
              <div className="news-card">
                <h3 className="news-title">Upcoming Wellness Retreat</h3>
                <p>Join us for a rejuvenating weekend retreat focused on wellness.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="upcoming-events">
          <div className="container">
            <h2 className="section-title">Upcoming Events</h2>
            <div className="events-grid">
              <div className="event-card">
                <h3 className="event-title">Health Expo 2024</h3>
                <p>Explore the latest in health and wellness at our annual expo.</p>
                <p className="event-date">March 18-22, 2024</p>
              </div>
              <div className="event-card">
                <h3 className="event-title">Yoga Workshop</h3>
                <p>Enhance your practice with our intensive yoga workshop.</p>
                <p className="event-date">April 10-12, 2024</p>
              </div>
              <div className="event-card">
                <h3 className="event-title">Nutrition Seminar</h3>
                <p>Learn about the latest trends in nutrition and healthy eating.</p>
                <p className="event-date">May 5-7, 2024</p>
              </div>
            </div>
          </div>
        </section>

        {/* Customer Testimonials */}
        <section className="customer-testimonials">
          <div className="container">
            <h2 className="section-title">Customer Testimonials</h2>
            <div className="testimonials-slider">
              <div className="testimonial-card">
                <p>"Healthify Me's training programs have helped me achieve my fitness goals."</p>
                <p className="testimonial-author">- Alex Johnson, Fitness Enthusiast</p>
              </div>
              <div className="testimonial-card">
                <p>"The nutrition counseling provided by Healthify Me has transformed my diet."</p>
                <p className="testimonial-author">- Emma Wilson, Health Conscious</p>
              </div>
              <div className="testimonial-card">
                <p>"The yoga classes at Healthify Me are the best I've ever attended."</p>
                <p className="testimonial-author">- Michael Brown, Yogi</p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="cta">
          <div className="container">
            <h2 className="cta-title">Start Your Wellness Journey Today</h2>
            <p className="cta-text">Be part of the future with healthcare.</p>
            <button className="cta-button">Get Started</button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-links">
            <Link to="#" className="footer-link">Privacy Policy</Link>
            <Link to="#" className="footer-link">Terms of Service</Link>
            <Link to="#" className="footer-link">Contact Us</Link>
          </div>
          <p>&copy; 2024 Healthcare. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default NvidiaHomePage;
