// NvidiaLogin.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './NvidiaLogin.css'; // Ensure the CSS file is imported

const NvidiaLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login logic here

    // Redirect to the home page after login
    navigate('/home');
  };

  return (
    <div className="login-container">
      <h2>Welcome Back</h2>
      <p>Sign in to your healthcare account</p>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <input
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path d="M0 0h24v24H0z" fill="none" />
            <path
              d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
              fill="currentColor"
            />
          </svg>
        </div>
        <div className="input-group">
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
            <path d="M0 0h24v24H0z" fill="none" />
            <path
              d="M12 17c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-7h-1V7c0-3.31-2.69-6-6-6S5 3.69 5 7v3H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V12c0-1.1-.9-2-2-2zm-6 0H6V7c0-2.21 1.79-4 4-4s4 1.79 4 4v3z"
              fill="currentColor"
            />
          </svg>
        </div>
        <button type="submit">Sign In</button>
      </form>
      <div className="links">
        <a href="/forgot-password">Forgot your password?</a>
        <a href="/create-account">Create an account</a>
      </div>
      <div className="terms">
        By signing in, you agree to healthcare's <a href="/terms-of-use">Terms of Use</a>
      </div>
    </div>
  );
};

export default NvidiaLogin;
