// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import NvidiaHomePage from './NvidiaHomePage';
import NvidiaLogin from './NvidiaLogin';
import CreateAccount from './CreateAccount'; // Import CreateAccount component
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<NvidiaLogin />} />
        <Route path="/home" element={<NvidiaHomePage />} />
        <Route path="/create-account" element={<CreateAccount />} /> {/* Add route for CreateAccount */}
      </Routes>
    </Router>
  );
}

export default App;
